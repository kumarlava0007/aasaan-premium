export const Data = [{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
},{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
},{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
},{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
},{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
},{
    class: "fas fa-th-large cardsIcons",
    p1: "View all",
    p2: "Products",
}];