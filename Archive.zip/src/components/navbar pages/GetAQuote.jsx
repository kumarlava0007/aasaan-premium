import React from 'react'

const GetAQuote = () => {
    return (
        <div>
        <br /><br />
        <br /><br />
            Get A Quote Page
        </div>
    )
}

export default GetAQuote
